var deck = ["1.png", "1.png", "2.png", "2.png", 
    "3.png", "3.png", "4.png", "4.png", 
    "5.png", "5.png", "6.png", "6.png", 
    "7.png", "7.png", "8.png", "8.png", 
    "9.png", "9.png", "10.png", "10.png", 
    "11.png", "11.png", "12.png", "12.png", 
    "13.png", "13.png", "14.png", "14.png",
    "15.png", "15.png", "16.png", "16.png",];

function cambiarImagen(imagen, indice) { 
    imagen.src = "./set1/" + deck[indice];
}

function shuffleDeck() {
    deck.sort(() => Math.random() - 0.5);
}